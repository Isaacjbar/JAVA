package mx.edu.utez.interfaces;

public interface Motor {
    void llenarTanque();
    int obtenerNivelCombustibleActual();
}